#include <string>
#include "type.h"

using namespace std;
typedef struct{
    string code;
    string place;
    Type type;
    
}Code;