#include <string>

using namespace std;

typedef struct{
    string data;
    string text;
    string global;
}Asm;